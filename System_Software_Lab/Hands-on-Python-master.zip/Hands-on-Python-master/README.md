# Hands-on-Python
## Requirements
1. Python3
2. Jupyter notebook


