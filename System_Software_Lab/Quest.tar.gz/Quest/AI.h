/*
* Goal: Include this file in order to
* use the functions defined in AI.c.
*/

void adjustLevel(void);
