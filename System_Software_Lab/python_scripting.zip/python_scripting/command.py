import sys

print(len(sys.argv))
for ele in sys.argv:
	print(ele)
