After doing zfs installation as described in the report , proceed as follows:

Command sequence for compression on
1  cd vdbench
2  replace examples/filesys/create_files with create_files file given in compression_gzip folder of submission
3  ./vdbench -f ./examples/filesys/create_files -o compression_gzip
    (Now you will get your output in folder named compression_gzip inside the vdbench directory)
4  zpool list files (to get space allocated)
5  zfs get all files (to get details like compressratio and compress algorithm used)
6  rm -Rf /files/*

Command sequence for compression off
1  cd vdbench
2  replace examples/filesys/create_files with create_files file given in compression_off folder of submission
3  ./vdbench -f ./examples/filesys/create_files -o compression_off
    (Now you will get your output in folder named compression_off inside the vdbench directory)
4  zpool list files (to get space allocated)
5  zfs get all files (to get details like compressratio and compress algorithm used)
6  rm -Rf /files/*

Command sequence for data deduplication on
1  cd vdbench
2  replace examples/filesys/create_files with create_files file given in datadedup_on folder of submission
3  ./vdbench -f ./examples/filesys/create_files -o datadedup_on
    (Now you will get your output in folder named datadedup_on inside the vdbench directory)
4  zpool list files (to get space allocated and dedup ratio)
5  rm -Rf /files/*

Command sequence for data deduplication off
1  cd vdbench
2  replace examples/filesys/create_files with create_files file given in datadedup_off folder of submission
3  ./vdbench -f ./examples/filesys/create_files -o datadedup_off
    (Now you will get your output in folder named datadedup_off inside the vdbench directory)
4  zpool list files (to get space allocated and dedup ratio)
5  rm -Rf /files/*




