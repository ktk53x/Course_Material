#include "types.h"
#include "stat.h"
#include "user.h"

int
main(void) 
{
    void *buf = (char*) malloc(365);
    void *temp = (char*) malloc(365);
    buf = itoa(buf, temp, 67, 432);
    if(strlen(buf)>20) 
        printf(1, "Memory Exceeded");
    else 
        printf(1, "%s\n", buf);
    exit();
} 