
// Shell.

#include "types.h"
#include "user.h"
#include "fcntl.h"


int
main(void)
{
  printf(1, "HELLO\n");
  exit();
}

